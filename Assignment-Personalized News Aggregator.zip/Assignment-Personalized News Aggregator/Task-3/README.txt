FastAPI Application:
This FastAPI application serves the categorized news articles via multiple endpoints:

GET /articles: Fetches all articles with optional filters for date range and category.
GET /articles/{id}: Retrieves a specific article by its ID.
GET /search: Allows searching for articles by keywords in their title or summary. The application reads articles from the news_articles_categorized.csv file and provides a RESTful API for accessing and filtering the data.