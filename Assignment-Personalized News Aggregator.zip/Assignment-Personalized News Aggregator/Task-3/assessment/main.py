from fastapi import FastAPI, HTTPException
from typing import List, Optional
from pydantic import BaseModel
import pandas as pd
from datetime import datetime

df = pd.read_csv('news_articles_categorized.csv')


app = FastAPI()


class Article(BaseModel):
    id: int
    Title: str
    Summary: str
    Publication_Date: str
    Source: str
    URL: str
    Category: str

def article_from_row(row):
    if isinstance(row['Publication Date'], pd.Timestamp):
        publication_date = row['Publication Date'].strftime("%Y-%m-%d")
    else:
        publication_date = row['Publication Date'] if pd.notna(row['Publication Date']) else "Unknown"

    return Article(
        id=row.name,
        Title=row['Title'],
        Summary=row['Summary'],
        Publication_Date=publication_date,
        Source=row['Source'],
        URL=row['URL'],
        Category=row['Category']
    )


@app.get("/articles", response_model=List[Article])
def get_articles(start_date: Optional[str] = None, end_date: Optional[str] = None, category: Optional[str] = None):
    articles = df

    if start_date:
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            articles['Publication Date'] = pd.to_datetime(articles['Publication Date'], errors='coerce')
            articles = articles[articles['Publication Date'] >= start]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD.")
    
    if end_date:
        try:
            end = datetime.strptime(end_date, "%Y-%m-%d")
            articles['Publication Date'] = pd.to_datetime(articles['Publication Date'], errors='coerce')
            articles = articles[articles['Publication Date'] <= end]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD.")

    
    if category:
        articles = articles[articles['Category'].str.lower() == category.lower()]

    if articles.empty:
        raise HTTPException(status_code=404, detail="No articles found")

    return [article_from_row(row) for _, row in articles.iterrows()]


@app.get("/articles/{id}", response_model=Article)
def get_article(id: int):
    if id >= len(df) or id < 0:
        raise HTTPException(status_code=404, detail="Article not found")

    return article_from_row(df.iloc[id])


@app.get("/search", response_model=List[Article])
def search_articles(query: str):
    filtered = df[df.apply(lambda row: query.lower() in row['Title'].lower() or query.lower() in row['Summary'].lower(), axis=1)]

    if filtered.empty:
        raise HTTPException(status_code=404, detail="No articles found for the given query")

    return [article_from_row(row) for _, row in filtered.iterrows()]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
