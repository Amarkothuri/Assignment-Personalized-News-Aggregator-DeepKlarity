News Scraping Script:
This script scrapes news articles from specified websites (e.g., BBC, New York Times) and saves the data as a CSV file. It extracts article titles, summaries, publication dates, sources, and URLs, then stores them in a structured format for further analysis.

